package com.jb.handicap;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HandicapApplicationTests {

	@Test
	void contextLoads() {
	}

}
