package com.jb.offroad;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OffroadApplicationTests {

	@Test
	void contextLoads() {
	}

}
